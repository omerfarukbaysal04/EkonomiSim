using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Unity.VisualScripting;
using UnityEngine.UI;

public class PuanKontrol : MonoBehaviour
{
    public static PuanKontrol Instance;
    public NüfusKontrol nüfusKontrol;

    public float dolarPuan = 33.0f;
    public float eskiDolar = 33.0f;
    public float euroPuan = 35.55f;
    public float eskiEuro=35.55f;
    public float altinPuan = 1210.40f;
    public float eskiAltin=1210.40f;
    public float dolarCarpan = 0.05f;
    public float euroDegisim;
    public float altinDegisim;
    public float euroCarpan = 0.05f;
    public float altinCarpan = 0.1f;
    public float dolarDegisim;
    public Button altinAl;
    public Button dolarAl;
    public Button euroAl;
    
    public TMP_Text dolarPuanText;
    public TMP_Text euroPuanText;
    public TMP_Text altinPuanText;
    public TMP_Text dolarDegisimText;
    public TMP_Text euroDegisimText;
    public TMP_Text altinDegisimText;
    
    public Image dolarDegisimImage;
    public Image euroDegisimImage;
    public Image altinDegisimImage;

    public Sprite positiveSprite;
    public Sprite negativeSprite;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        UpdatePuanText();
        StartCoroutine(PuanlariOtoArttir());
        UpdateButtonInteractability();
    }

    void Update()
    {
        DegisimKontrol();
        UpdateButtonInteractability();
    }
    void UpdateButtonInteractability()
    {
        altinAl.interactable =  nüfusKontrol.tlPuan >= 100000;
        dolarAl.interactable =  nüfusKontrol.tlPuan >= 100000;
        euroAl.interactable =  nüfusKontrol.tlPuan >= 100000;
    }

    IEnumerator PuanlariOtoArttir()
    {
        while (true)
        {
            yield return new WaitForSeconds(2.5f);
            dolarPuan += 0.05f;
            euroPuan += 0.05f;
            altinPuan += 0.5f;

            UpdatePuanText();
        }
    }

    public void UpdatePuanText()
    {
        dolarPuanText.text = dolarPuan.ToString("F2");
        euroPuanText.text = euroPuan.ToString("F2");
        altinPuanText.text = altinPuan.ToString("F2");
        nüfusKontrol.tlPuanText.text = nüfusKontrol.tlPuan.ToString("F2");
    }
    public void AltinAl()
    {
        if(nüfusKontrol.tlPuan>=100000)
        {
            altinAl.interactable=true;
            altinPuan-=25;
            nüfusKontrol.tlPuan-=100000;
            nüfusKontrol.tlPuanText.text=nüfusKontrol.tlPuan.ToString();
        }
        UpdatePuanText();
    }
   
    public void DolarAl()
    {
         if(nüfusKontrol.tlPuan>=100000)
        {
            dolarAl.interactable=true;
            dolarPuan-=2.5f;
            nüfusKontrol.tlPuan-=100000;
            nüfusKontrol.tlPuanText.text=nüfusKontrol.tlPuan.ToString();
        }
        UpdatePuanText();
    }
    
    public void EuroAl()
    {
         if(nüfusKontrol.tlPuan>=100000)
        {
            euroAl.interactable=true;
            euroPuan-=2.5f;
            nüfusKontrol.tlPuan-=100000;
            nüfusKontrol.tlPuanText.text=nüfusKontrol.tlPuan.ToString();
        }
        UpdatePuanText();
    }
    void DegisimKontrol()
    {
        dolarDegisim = eskiDolar - dolarPuan;
        euroDegisim = eskiEuro - euroPuan;
        altinDegisim = eskiAltin - altinPuan;

        if (Mathf.Abs(dolarDegisim) >= 1.5f)
        {
            nüfusKontrol.mutluluk += dolarDegisim > 0 ? 5 : -5;
            eskiDolar = dolarPuan;
            nüfusKontrol.mutlulukText.text = nüfusKontrol.mutluluk.ToString("F1");
        }

        if (Mathf.Abs(euroDegisim) >= 1.5f)
        {
            nüfusKontrol.mutluluk += euroDegisim > 0 ? 5 : -5;
            eskiEuro = euroPuan;
            nüfusKontrol.mutlulukText.text = nüfusKontrol.mutluluk.ToString("F1");
        }

        if (Mathf.Abs(altinDegisim) >= 5f)
        {
            nüfusKontrol.mutluluk += altinDegisim > 0 ? 10 : -10;
            eskiAltin = altinPuan;
            nüfusKontrol.mutlulukText.text = nüfusKontrol.mutluluk.ToString("F1");
        }

        nüfusKontrol.mutlulukText.text = nüfusKontrol.mutluluk.ToString("F1");
    }
    public void UpdateWeeklyChanges()
    {
        UpdateChangeTextAndImage(dolarDegisim,dolarDegisimText,dolarDegisimImage);
        UpdateChangeTextAndImage(euroDegisim,euroDegisimText,euroDegisimImage);
        UpdateChangeTextAndImage(altinDegisim,altinDegisimText,altinDegisimImage);
    }

    void UpdateChangeTextAndImage(float degisim,TMP_Text text,Image image)
    {
        text.text = degisim.ToString("F2");
        image.sprite = degisim >= 0 ? positiveSprite : negativeSprite;
    }

    public void PuanEkle(string tur)
    {
        switch (tur)
        {
            case "dolar":
                dolarPuan -= dolarCarpan;
                dolarPuanText.text = dolarPuan.ToString("F2");
                break;
            case "euro":
                euroPuan -= euroCarpan;
                euroPuanText.text = euroPuan.ToString("F2");
                break;
            case "altin":
                altinPuan -= altinCarpan;
                altinPuanText.text = altinPuan.ToString("F2");
                break;
        }
    }
}




